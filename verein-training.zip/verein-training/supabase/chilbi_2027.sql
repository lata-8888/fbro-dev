-- =====================================================================
-- Vorschlag Chilbi 2027 aus dem «Einsatzplan Chilbistand 2026»
-- Im Supabase-Dashboard unter «SQL Editor» einfügen und mit «Run» ausführen.
--
-- - Füllt den Anlass «Chilbi 2027» mit Tagen, Schichten und Rollen.
-- - Alle Daten sind um 52 Wochen verschoben (gleiche Wochentage wie 2026).
-- - Wenn «Chilbi 2027» schon Tage hat, wird nichts geändert.
-- - Die Namen sind Vorschläge aus 2026 und können in der App angepasst werden.
-- =====================================================================
do $$
declare
  e uuid; d uuid; s uuid;
begin
  select id into e from public.cc_events where name = 'Chilbi 2027' order by created_at limit 1;
  if e is null then
    insert into public.cc_events (name, active) values ('Chilbi 2027', true) returning id into e;
  end if;
  if exists (select 1 from public.cc_days where event_id = e) then
    raise notice 'Chilbi 2027 hat bereits Tage. Es wurde nichts geändert.';
    return;
  end if;
  insert into public.cc_days (event_id, day, name) values (e, '2027-09-01', 'Aufstellen') returning id into d;
  insert into public.cc_shifts (day_id, start_time, end_time, name) values (d, '18:00', '21:00', 'Treffpunkt chez Cacco') returning id into s;
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Team', '[{"name": "Marco Citrini"}, {"name": "Marc Thamm"}, {"name": "Christian Harder"}, {"name": "Tobias Waltert"}, {"name": "Steph Cremer"}, {"name": "Richi Miotti"}, {"name": "Dave Hess"}]'::jsonb, 0);
  insert into public.cc_shifts (day_id, start_time, end_time, name) values (d, '18:30', '21:00', 'Treffpunkt Langweg') returning id into s;
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Team', '[{"name": "Guido Zimmerli"}, {"name": "Ruedi Bachmann"}, {"name": "Beni Anderegg"}, {"name": "Thomas Walter"}, {"name": "Christian Kunz"}, {"name": "Bruno Daneffel"}, {"name": "Rolf G. Werner"}, {"name": "Daniel Steiner"}, {"name": "Roger Dettling"}]'::jsonb, 0);
  insert into public.cc_days (event_id, day, name) values (e, '2027-09-03', 'Standbetrieb') returning id into d;
  insert into public.cc_shifts (day_id, start_time, end_time, name) values (d, '14:00', '19:00', null) returning id into s;
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Kasse', '[{"name": "Guido Zimmerli"}]'::jsonb, 0);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Chnobli-Brot & Ausgabe', '[{"name": "Rolf G. Werner"}]'::jsonb, 1);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Grill', '[{"name": "Bruno Daneffel"}]'::jsonb, 2);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'OK', '[{"name": "Markus Notz"}]'::jsonb, 3);
  insert into public.cc_shifts (day_id, start_time, end_time, name) values (d, '19:00', '00:30', null) returning id into s;
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Kasse', '[{"name": "Christoph Aeberli"}]'::jsonb, 0);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Chnobli-Brot & Ausgabe', '[{"name": "Marco Meroni"}]'::jsonb, 1);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Grill', '[{"name": "Marco Citrini"}]'::jsonb, 2);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Aussenservice', '[{"name": "Thomas Walter"}]'::jsonb, 3);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'OK', '[{"name": "Daniel Oetterli"}]'::jsonb, 4);
  insert into public.cc_days (event_id, day, name) values (e, '2027-09-04', 'Standbetrieb') returning id into d;
  insert into public.cc_shifts (day_id, start_time, end_time, name) values (d, '14:00', '19:00', null) returning id into s;
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Kasse', '[{"name": "Beat Latanzio"}]'::jsonb, 0);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Chnobli-Brot & Ausgabe', '[{"name": "Balthasar Bruggmann"}]'::jsonb, 1);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Grill', '[{"name": "Dave Hess"}]'::jsonb, 2);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'OK', '[{"name": "Domi Ulrich"}]'::jsonb, 3);
  insert into public.cc_shifts (day_id, start_time, end_time, name) values (d, '19:00', '00:30', null) returning id into s;
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Kasse', '[{"name": "Daniel Steiner"}]'::jsonb, 0);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Chnobli-Brot & Ausgabe', '[{"name": "Ruedi Bachmann"}]'::jsonb, 1);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Grill', '[{"name": "Marc Thamm"}]'::jsonb, 2);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Aussenservice', '[{"name": "Christian Kunz"}]'::jsonb, 3);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'OK', '[{"name": "Claudio Vanoli"}]'::jsonb, 4);
  insert into public.cc_days (event_id, day, name) values (e, '2027-09-05', 'Standbetrieb') returning id into d;
  insert into public.cc_shifts (day_id, start_time, end_time, name) values (d, '12:00', '18:00', 'OK ab 12:00') returning id into s;
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'OK', '[{"name": "Domi Ulrich"}, {"name": "Daniel Oetterli"}]'::jsonb, 0);
  insert into public.cc_shifts (day_id, start_time, end_time, name) values (d, '13:30', '18:00', null) returning id into s;
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Kasse', '[{"name": "Joel Reischmann"}]'::jsonb, 0);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Chnobli-Brot & Ausgabe', '[{"name": "Gianluca Steiner"}]'::jsonb, 1);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Grill', '[{"name": "Pascal Hartmann"}]'::jsonb, 2);
  insert into public.cc_shifts (day_id, start_time, end_time, name) values (d, '18:00', '22:30', null) returning id into s;
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Kasse', '[{"name": "Tobias Walthert"}]'::jsonb, 0);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Chnobli-Brot & Ausgabe', '[]'::jsonb, 1);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Grill', '[{"name": "Christian Harder"}]'::jsonb, 2);
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'OK', '[{"name": "Claudio Vanoli"}, {"name": "Markus Notz"}]'::jsonb, 3);
  insert into public.cc_days (event_id, day, name) values (e, '2027-09-06', 'Abräumen') returning id into d;
  insert into public.cc_shifts (day_id, start_time, end_time, name) values (d, '18:30', '21:00', 'anschliessend Unihockey') returning id into s;
  insert into public.cc_roles (shift_id, name, persons, sort) values (s, 'Team', '[{"name": "Steph Cremer"}, {"name": "Beni Anderegg"}, {"name": "Marco Citrini"}, {"name": "Guido Zimmerli"}, {"name": "Marco Meroni"}, {"name": "Pascal Hartmann"}, {"name": "Ruedi Bachmann"}, {"name": "Ty Un"}]'::jsonb, 0);
  raise notice 'Chilbi 2027 wurde befüllt.';
end $$;
