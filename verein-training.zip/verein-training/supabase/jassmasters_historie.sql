-- =====================================================================
-- Import/Korrektur: die zehn historischen Jassmasters-Runden (27–36).
-- Im Supabase-Dashboard unter «SQL Editor» einfügen und mit «Run» ausführen.
-- Vorher muss das normale supabase/schema.sql bereits ausgeführt worden sein
-- (für die Spalten closed und manual_ranking auf jass_days).
--
-- Diese Zahlen sind durch die hochgeladene Excel-Tabelle «vergangene.xlsx»
-- gegengeprüft (Stand: 1. Oktober 2026). Gegenüber einer früheren, von Hand
-- abgetippten Version wurden dabei vier Runden korrigiert (28, 32, 34, 35/36 –
-- u. a. Mäke Notz, Beni Anderegg und Marco Meroni waren falschen Runden
-- zugeordnet).
--
-- Jede Runde wird als abgeschlossener Jasstag angelegt (closed = true), mit
-- Monat und Jahr als Datum (jeweils der 1. des Monats, da kein genauer Tag
-- bekannt ist) und der Rangliste als feste Punktzahl pro Person. Teilnehmer
-- und Spielplan bleiben leer, da dafür keine Einzelspiel-Daten vorliegen.
--
-- Dieses Skript ist ein UPSERT: Ist bereits eine Runde mit demselben Namen
-- vorhanden (z. B. aus einem früheren, inzwischen überholten Lauf), wird
-- ihre Rangliste aktualisiert statt übersprungen. Das Skript kann also
-- gefahrlos mehrfach ausgeführt werden und bringt bestehende Einträge immer
-- auf den Stand dieser Datei.
-- =====================================================================
do $$
declare
  sid uuid;
  rounds jsonb := '[
    {"name":"Runde 27","day":"2014-04-01","ranking":[
      {"name":"Marco Citrini","points":32},
      {"name":"Phil Cremer","points":28},
      {"name":"Ruedi Bachmann","points":24},
      {"name":"Claudio Vanoli","points":20},
      {"name":"Thomas Walter","points":16},
      {"name":"Pascal Hartmann","points":12},
      {"name":"Christoph Aeberli","points":8},
      {"name":"Dani (Taps) Steiner","points":4}
    ]},
    {"name":"Runde 28","day":"2014-10-01","ranking":[
      {"name":"Phil Cremer","points":32},
      {"name":"Gregi Reich","points":28},
      {"name":"Beat Latanzio","points":24},
      {"name":"Claudio Vanoli","points":20},
      {"name":"Stephan Cremer","points":16},
      {"name":"Ruedi Bachmann","points":12},
      {"name":"Hans Hartmann","points":8},
      {"name":"Marco Citrini","points":4},
      {"name":"Pascal Hartmann","points":0}
    ]},
    {"name":"Runde 29","day":"2015-02-01","ranking":[
      {"name":"Gregi Reich","points":32},
      {"name":"Stephan Cremer","points":28},
      {"name":"Marco Citrini","points":24},
      {"name":"Claudio Vanoli","points":20},
      {"name":"Christoph Aeberli","points":16},
      {"name":"Pascal Hartmann","points":12},
      {"name":"Phil Cremer","points":8},
      {"name":"Ruedi Bachmann","points":4}
    ]},
    {"name":"Runde 30","day":"2015-04-01","ranking":[
      {"name":"Thomas Walter","points":32},
      {"name":"Phil Cremer","points":28},
      {"name":"Christoph Aeberli","points":24},
      {"name":"Marco Citrini","points":20},
      {"name":"Gregi Reich","points":16},
      {"name":"Claudio Vanoli","points":12},
      {"name":"Stephan Cremer","points":8},
      {"name":"Ruedi Bachmann","points":4}
    ]},
    {"name":"Runde 31","day":"2016-04-01","ranking":[
      {"name":"Gregi Reich","points":32},
      {"name":"Claudio Vanoli","points":28},
      {"name":"Ruedi Bachmann","points":24},
      {"name":"Pascal Hartmann","points":20},
      {"name":"Marco Citrini","points":16},
      {"name":"Alex Häusler","points":12},
      {"name":"Thomas Walter","points":8},
      {"name":"Phil Cremer","points":4}
    ]},
    {"name":"Runde 32","day":"2017-04-01","ranking":[
      {"name":"Mäke Notz","points":32},
      {"name":"Pascal Hartmann","points":28},
      {"name":"Stephan Cremer","points":24},
      {"name":"Marco Citrini","points":20},
      {"name":"Phil Cremer","points":16},
      {"name":"Gregi Reich","points":12},
      {"name":"Claudio Vanoli","points":8},
      {"name":"Thomas Walter","points":4}
    ]},
    {"name":"Runde 33","day":"2022-10-01","ranking":[
      {"name":"Mäke Notz","points":32},
      {"name":"Hans Hartmann","points":28},
      {"name":"Claudio Vanoli","points":24},
      {"name":"Dani Oetterli","points":20},
      {"name":"Thomas Walter","points":16},
      {"name":"Roli Steiger","points":12},
      {"name":"Phil Cremer","points":8},
      {"name":"Ruedi Bachmann","points":4}
    ]},
    {"name":"Runde 34","day":"2023-10-01","ranking":[
      {"name":"Beni Anderegg","points":32},
      {"name":"Mäke Notz","points":28},
      {"name":"Claudio Vanoli","points":24},
      {"name":"Marco Meroni","points":20},
      {"name":"Stephan Cremer","points":16},
      {"name":"Thomas Walter","points":12},
      {"name":"Dani Oetterli","points":8},
      {"name":"Ruedi Bachmann","points":4},
      {"name":"Alex Häusler","points":2}
    ]},
    {"name":"Runde 35","day":"2024-10-01","ranking":[
      {"name":"Dani Oetterli","points":32},
      {"name":"Christian Kunz","points":28},
      {"name":"Thomas Walter","points":24},
      {"name":"Claudio Vanoli","points":20},
      {"name":"Dani (Taps) Steiner","points":16},
      {"name":"Pascal Hartmann","points":12},
      {"name":"Ruedi Bachmann","points":8},
      {"name":"Marco Citrini","points":4}
    ]},
    {"name":"Runde 36","day":"2025-10-01","ranking":[
      {"name":"Ruedi Bachmann","points":32},
      {"name":"Marco Citrini","points":28},
      {"name":"Christian Kunz","points":24},
      {"name":"Claudio Vanoli","points":20},
      {"name":"Beat Latanzio","points":16},
      {"name":"Mäke Notz","points":12},
      {"name":"Phil Cremer","points":8},
      {"name":"Dani Oetterli","points":4}
    ]}
  ]';
  r jsonb;
  enriched jsonb;
  existing_id uuid;
begin
  select id into sid from public.jass_series order by created_at limit 1;
  if sid is null then
    insert into public.jass_series (name) values ('Jassmasters') returning id into sid;
  end if;

  for r in select * from jsonb_array_elements(rounds) loop
    -- Mitglieder-Namen werden, falls vorhanden, mit der echten Profil-ID verknüpft,
    -- damit die Person z. B. beim Antippen des Namens erkannt wird.
    select jsonb_agg(
             case when p.id is not null
               then jsonb_build_object('name', p.name, 'id', p.id, 'points', (entry->>'points')::int)
               else jsonb_build_object('name', entry->>'name', 'id', null, 'points', (entry->>'points')::int)
             end
           )
      into enriched
      from jsonb_array_elements(r->'ranking') as entry
      left join public.profiles p
        on lower(p.name) = lower(entry->>'name') and not p.is_guest;

    select id into existing_id from public.jass_days where name = r->>'name';
    if existing_id is null then
      insert into public.jass_days (series_id, day, name, closed, players, scores, manual_ranking)
      values (sid, (r->>'day')::date, r->>'name', true,
              '[null,null,null,null,null,null,null,null]'::jsonb, '{}'::jsonb, enriched);
    else
      update public.jass_days
         set day = (r->>'day')::date, manual_ranking = enriched, closed = true
       where id = existing_id;
    end if;
  end loop;
end $$;
