-- =====================================================================
-- Import: zehn neue Mitglieder (Passivmitglieder und Friends & Family).
-- Im Supabase-Dashboard unter «SQL Editor» einfügen und mit «Run» ausführen.
-- Vorher muss das normale supabase/schema.sql bereits ausgeführt worden sein.
--
-- WICHTIGER HINWEIS: Claude hat keinen direkten Zugriff auf eure Supabase-
-- Datenbank. Dieses Skript legt Konten so an, wie es die App selbst beim
-- «Gruppen → +» normalerweise über die Supabase-Auth-API tut, aber direkt
-- per SQL – inklusive des nötigen Eintrags in auth.identities, damit sich
-- die Personen danach normal per Handynummer + PIN anmelden können. Das ist
-- der unterstützte Aufbau für aktuelle Supabase-Projekte; sollte sich bei
-- einer Person die Anmeldung trotzdem nicht sofort einrichten lassen, kannst
-- du sie alternativ jederzeit ganz normal über «Admin → Gruppen → +» von
-- Hand nachtragen (dauert pro Person etwa 20 Sekunden).
--
-- Jede Person erhält als Standard-PIN die letzten 6 Ziffern ihrer eigenen
-- Handynummer – wie bei jeder anderen neu hinzugefügten Person auch. Das
-- Skript überspringt automatisch jede Handynummer, die schon registriert ist
-- (kann also gefahrlos mehrfach ausgeführt werden).
--
-- Drei der Namen (Phil Cremer, Stephan Cremer, Ruedi Bachmann) kommen auch
-- in den historischen Jassmasters-Ranglisten vor. Nach diesem Import zeigt
-- die «Ewige Rangliste» ihren Namen als antippbaren Mitglieder-Chip an,
-- die alten Ranglisten-Einträge selbst bleiben unverändert (reine Anzeige).
-- =====================================================================
do $$
declare
  club_code   text;
  new_user_id uuid;
  rec         record;
  rows_data   text[][] := array[
    array['Ivo Lautner',          'other',   '+41796340764'],
    array['Martin Eichenberger',  'passive', '+41794325935'],
    array['Niki Dopler',          'passive', '+41792086259'],
    array['Phil Cremer',          'passive', '+41794286991'],
    array['Roger Dettling',       'passive', '+41795923503'],
    array['Rolf Latanzio',        'passive', '+41796540132'],
    array['Rolf Bachmann',        'passive', '+41794579285'],
    array['Ruedi Bachmann',       'passive', '+41792367928'],
    array['Stephan Cremer',       'passive', '+41798121054'],
    array['Gianluca Steiner',     'other',   '+41774499325']
  ];
  r          text[];
  v_name     text;
  v_group    text;
  v_phone    text;
  v_email    text;
  v_pin      text;
begin
  select value into club_code from public.app_settings where key = 'club_code';

  foreach r slice 1 in array rows_data loop
    v_name  := r[1];
    v_group := r[2];
    v_phone := r[3];
    v_email := replace(v_phone, '+', '') || '@phone-login.app';
    v_pin   := right(regexp_replace(v_phone, '\D', '', 'g'), 6);

    if exists (select 1 from public.profiles where phone = v_phone) then
      raise notice 'Übersprungen (Handynummer bereits registriert): % (%)', v_name, v_phone;
      continue;
    end if;

    new_user_id := gen_random_uuid();

    insert into auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
      created_at, updated_at,
      confirmation_token, recovery_token, email_change_token_new, email_change
    ) values (
      '00000000-0000-0000-0000-000000000000',
      new_user_id, 'authenticated', 'authenticated', v_email,
      crypt(v_pin, gen_salt('bf')),
      now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      jsonb_build_object('name', v_name, 'phone', v_phone, 'club_code', coalesce(club_code, ''), 'created_by_admin', 'true'),
      now(), now(), '', '', '', ''
    );

    insert into auth.identities (
      id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at
    ) values (
      gen_random_uuid(), new_user_id, new_user_id::text,
      jsonb_build_object('sub', new_user_id::text, 'email', v_email),
      'email', now(), now(), now()
    );

    -- handle_new_user() hat soeben die Profilzeile mit is_candidate = false angelegt
    -- (wegen created_by_admin); jetzt noch die richtige Gruppe setzen.
    update public.profiles
       set is_passive   = (v_group = 'passive'),
           is_supporter = (v_group = 'other')
     where id = new_user_id;

    raise notice 'Angelegt: % (% · PIN %)', v_name, v_phone, v_pin;
  end loop;
end $$;
